create view articles as
select `blog_cao01`.`zj_articles`.`user_id`         AS `user_id`,
       `blog_cao01`.`zj_users`.`user_name`          AS `user_name`,
       `blog_cao01`.`zj_articles`.`article_id`      AS `article_id`,
       `blog_cao01`.`zj_articles`.`article_title`   AS `article_title`,
       `blog_cao01`.`zj_articles`.`article_content` AS `article_content`
from (`blog_cao01`.`zj_users`
         join `blog_cao01`.`zj_articles`)
where (`blog_cao01`.`zj_users`.`user_id` = `blog_cao01`.`zj_articles`.`user_id`);

