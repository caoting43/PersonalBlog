create view friends as
select `blog_cao01`.`zj_user_friends`.`user_id`         AS `user_id`,
       `blog_cao01`.`zj_users`.`user_name`              AS `user_name`,
       `blog_cao01`.`zj_user_friends`.`user_friends_id` AS `user_friends_id`,
       `blog_cao01`.`zj_user_friends`.`user_note`       AS `user_note`
from (`blog_cao01`.`zj_users`
         join `blog_cao01`.`zj_user_friends`)
where (`blog_cao01`.`zj_users`.`user_id` = `blog_cao01`.`zj_user_friends`.`user_id`);

